export const API_URL = process.env.STRAPI_API_URL || "http://localhost:1337";
